import json
from pathlib import Path
import subprocess
import sys
import shutil
import tempfile
import unittest
from server import Session, review

CASE = dict(project_type="shed", municipality="Kastrup", area_m2=None,
            height_m=None, boundary_distance_m=None, has_site_plan=False,
            has_drawings=False, has_local_plan_reference=False)


class Tests(unittest.TestCase):
    def test_missing_stays_missing(self):
        result = review(CASE)
        self.assertEqual(len(result["documents_missing"]), 3)
        self.assertFalse(result["permit_approved"])

    def test_complete_does_not_grant_permission(self):
        result = review(dict(CASE, area_m2=12, height_m=2, boundary_distance_m=3,
                             has_site_plan=True, has_drawings=True, has_local_plan_reference=True))
        self.assertEqual(result["documents_missing"], [])
        self.assertFalse(result["permit_approved"])
        self.assertFalse(result["documents_independently_verified"])

    def test_invalid_values(self):
        for change in ({"area_m2": True}, {"area_m2": float('nan')},
                       {"has_drawings": "yes"}, {"address": "private"}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                review(dict(CASE, **change))

    def test_initialization_required(self):
        self.assertIn("error", Session().handle({"jsonrpc": "2.0", "id": 1, "method": "tools/list"}))

    def test_standalone_package(self):
        with tempfile.TemporaryDirectory(prefix="byggeklar-package-test-") as folder:
            source = Path(__file__).parent
            shutil.copy2(source / "server.py", folder)
            shutil.copytree(source / "baseline", Path(folder) / "baseline")
            run = subprocess.run([sys.executable, str(Path(folder) / "server.py")],
                cwd=folder, input='', capture_output=True, text=True, timeout=5)
            self.assertEqual(run.returncode, 0, run.stderr)

    def test_real_stdio_sequence(self):
        messages = [
            {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-11-25", "capabilities": {}, "clientInfo": {"name": "test", "version": "1"}}},
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
            {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "review_building_evidence", "arguments": CASE}},
        ]
        run = subprocess.run([sys.executable, str(Path(__file__).with_name("server.py"))],
            input='\n'.join(map(json.dumps, messages))+'\n', text=True, capture_output=True, timeout=5, check=True)
        replies = list(map(json.loads, run.stdout.splitlines()))
        self.assertEqual(len(replies), 3)
        self.assertEqual(replies[0]["result"]["protocolVersion"], "2025-11-25")
        self.assertEqual(replies[1]["result"]["tools"][0]["name"], "review_building_evidence")
        self.assertEqual(len(replies[2]["result"]["structuredContent"]["documents_missing"]), 3)


if __name__ == "__main__":
    unittest.main()
