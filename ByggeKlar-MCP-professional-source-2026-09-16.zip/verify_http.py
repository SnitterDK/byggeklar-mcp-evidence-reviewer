"""Real loopback HTTP client check. Start http_server.py first."""
import asyncio
import json
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client


async def main():
    async with streamablehttp_client('http://127.0.0.1:8766/mcp') as (read, write, _):
        async with ClientSession(read, write) as client:
            init = await client.initialize()
            assert init.protocolVersion == '2025-11-25'
            tools = await client.list_tools()
            assert any(t.name == 'review_building_evidence' for t in tools.tools)
            case = dict(project_type='shed', municipality='Example', area_m2=None,
                        height_m=None, boundary_distance_m=None, has_site_plan=False,
                        has_drawings=False, has_local_plan_reference=False)
            result = await client.call_tool('review_building_evidence', case)
            assert not result.isError
            pack = result.structuredContent or json.loads(result.content[0].text)
            assert pack['permit_approved'] is False
            assert len(pack['documents_missing']) == 3
            case['area_m2'] = -1
            invalid = await client.call_tool('review_building_evidence', case)
            assert invalid.isError
            await client.send_ping()
            print(json.dumps(dict(protocol=init.protocolVersion,
                  transport='Streamable HTTP', handshake=True, discovery=True,
                  actual_tool_call=True, negative_measurement_rejected=True,
                  permit_not_approved=True, ping=True)))


if __name__ == '__main__':
    asyncio.run(main())
