"""Unmodified reused ByggeKlar engine; see PROVENANCE.md."""
