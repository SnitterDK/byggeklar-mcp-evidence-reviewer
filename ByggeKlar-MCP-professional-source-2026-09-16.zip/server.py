"""Local MCP/stdio adapter for the existing ByggeKlar evidence checklist."""
import json
import math
import sys
from dataclasses import asdict

from baseline.engine import build_permit_pack
from baseline.models import BuildingCase

FIELDS = {
    "project_type": {"type": "string", "minLength": 1, "maxLength": 100},
    "municipality": {"type": "string", "minLength": 1, "maxLength": 100},
    **{key: {"type": ["number", "null"], "minimum": 0} for key in (
        "area_m2", "height_m", "boundary_distance_m")},
    **{key: {"type": "boolean"} for key in (
        "has_site_plan", "has_drawings", "has_local_plan_reference")},
}
TOOL = {
    "name": "review_building_evidence",
    "description": "Review an illustrative building-document checklist. Missing facts remain unknown. This does not determine permit eligibility, validate local rules, submit applications or send messages.",
    "inputSchema": {"type": "object", "properties": FIELDS,
                    "required": list(FIELDS), "additionalProperties": False},
    "annotations": {"readOnlyHint": True, "destructiveHint": False,
                    "idempotentHint": True, "openWorldHint": False},
}


def review(arguments):
    if not isinstance(arguments, dict) or set(arguments) != set(FIELDS):
        raise ValueError("Supply exactly the checklist fields; no address or personal data needed")
    for key in ("project_type", "municipality"):
        if not isinstance(arguments[key], str) or not 1 <= len(arguments[key].strip()) <= 100:
            raise ValueError("Project type and municipality must be short nonempty text")
    for key in ("area_m2", "height_m", "boundary_distance_m"):
        value = arguments[key]
        if value is not None and (type(value) not in (float, int) or not math.isfinite(value) or value < 0):
            raise ValueError("Measurements must be finite nonnegative numbers or null")
    for key in ("has_site_plan", "has_drawings", "has_local_plan_reference"):
        if type(arguments[key]) is not bool:
            raise ValueError("Document flags must be explicit booleans")
    pack = asdict(build_permit_pack(BuildingCase(**arguments)))
    pack["permit_approved"] = False
    pack["documents_independently_verified"] = False
    pack["source"] = "Existing ByggeKlar illustrative checklist; user-reported facts"
    return pack


class Session:
    def __init__(self):
        self.initialized = False
        self.ready = False

    def handle(self, message):
        if not isinstance(message, dict) or message.get("jsonrpc") != "2.0" or not isinstance(message.get("method"), str):
            return {"jsonrpc": "2.0", "id": None, "error": {"code": -32600, "message": "Invalid request"}}
        method, identifier = message["method"], message.get("id")
        if "id" not in message:
            if method == "notifications/initialized" and self.initialized:
                self.ready = True
            return None
        response = {"jsonrpc": "2.0", "id": identifier}
        params = message.get("params", {})
        if not isinstance(params, dict):
            response["error"] = {"code": -32602, "message": "Parameters must be an object"}
        elif method == "initialize":
            self.initialized = True
            self.ready = False
            response["result"] = {"protocolVersion": "2025-11-25",
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "byggeklar-evidence", "version": "0.1.0"}}
        elif method == "ping":
            response["result"] = {}
        elif not self.ready:
            response["error"] = {"code": -32000, "message": "Initialize session first"}
        elif method == "tools/list":
            response["result"] = {"tools": [TOOL]}
        elif method == "tools/call":
            if params.get("name") != TOOL["name"]:
                response["error"] = {"code": -32602, "message": "Unknown tool"}
            else:
                try:
                    result = review(params.get("arguments"))
                    response["result"] = {"content": [{"type": "text", "text": json.dumps(result)}],
                                          "structuredContent": result, "isError": False}
                except ValueError as error:
                    response["result"] = {"content": [{"type": "text", "text": str(error)}], "isError": True}
        else:
            response["error"] = {"code": -32601, "message": "Method not found"}
        return response


def main():
    session = Session()
    for line in sys.stdin:
        try:
            if len(line) > 65536:
                raise ValueError("Message too long")
            response = session.handle(json.loads(line))
        except (ValueError, TypeError):
            response = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Invalid JSON message"}}
        if response is not None:
            print(json.dumps(response), flush=True)


if __name__ == "__main__":
    main()
