import unittest
import io
import json
from unittest.mock import patch
from demo import call_review, Handler


class DemoTests(unittest.TestCase):
    def test_browser_bridge_calls_real_mcp(self):
        case = dict(project_type='shed', municipality='Example', area_m2=None,
                    height_m=None, boundary_distance_m=None, has_site_plan=False,
                    has_drawings=False, has_local_plan_reference=False)
        result = call_review(case)
        self.assertFalse(result['isError'])
        self.assertEqual(len(result['structuredContent']['documents_missing']), 3)
        self.assertFalse(result['structuredContent']['permit_approved'])

    def test_invalid_case_is_rejected(self):
        self.assertTrue(call_review({})['isError'])

    def request(self, body=b'{}', **overrides):
        handler = object.__new__(Handler)
        handler.path = '/review'
        handler.headers = {'Host': '127.0.0.1:8765',
                           'Origin': 'http://127.0.0.1:8765',
                           'Content-Length': str(len(body))}
        handler.headers.update(overrides)
        handler.rfile = io.BytesIO(body)
        responses = []
        handler.reply = lambda status, data: responses.append((status, data))
        handler.do_POST()
        return responses[0]

    def test_foreign_origin_does_not_run_tool(self):
        with patch('demo.call_review') as tool:
            self.assertEqual(self.request(Origin='https://example.com')[0], 403)
            tool.assert_not_called()

    def test_foreign_host_does_not_run_tool(self):
        with patch('demo.call_review') as tool:
            self.assertEqual(self.request(Host='example.com')[0], 403)
            tool.assert_not_called()

    def test_oversized_body_does_not_run_tool(self):
        with patch('demo.call_review') as tool:
            self.assertEqual(self.request(**{'Content-Length': '16001'})[0], 413)
            tool.assert_not_called()

    def test_malformed_json_is_rejected(self):
        self.assertEqual(self.request(b'{')[0], 400)

    def test_post_runs_actual_mcp_and_returns_no_permit_approval(self):
        case = dict(project_type='shed', municipality='Example', area_m2=12,
                    height_m=2, boundary_distance_m=3, has_site_plan=True,
                    has_drawings=True, has_local_plan_reference=True)
        status, body = self.request(json.dumps(case).encode())
        self.assertEqual(status, 200)
        result = json.loads(body)
        self.assertFalse(result['isError'])
        self.assertFalse(result['structuredContent']['permit_approved'])


if __name__ == '__main__':
    unittest.main()
