"""Loopback Streamable HTTP entry point; requires the pinned MCP SDK.

Not publicly deployed or connected to Alexa. Never expose without reviewing
authentication and deployment safeguards first.
"""
from typing import Optional

from mcp.server.fastmcp import FastMCP
from server import review

mcp = FastMCP('ByggeKlar evidence review', host='127.0.0.1', port=8766,
              json_response=True)


@mcp.tool()
def review_building_evidence(
    project_type: str,
    municipality: str,
    area_m2: Optional[float],
    height_m: Optional[float],
    boundary_distance_m: Optional[float],
    has_site_plan: bool,
    has_drawings: bool,
    has_local_plan_reference: bool,
) -> dict:
    """Review self-reported building evidence, never grant a permit or send anything."""
    return review(dict(
        project_type=project_type, municipality=municipality,
        area_m2=area_m2, height_m=height_m,
        boundary_distance_m=boundary_distance_m,
        has_site_plan=has_site_plan, has_drawings=has_drawings,
        has_local_plan_reference=has_local_plan_reference,
    ))


if __name__ == '__main__':
    mcp.run(transport='streamable-http')
