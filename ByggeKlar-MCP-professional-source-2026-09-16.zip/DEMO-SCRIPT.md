# ByggeKlar evidence review — recording script

Status: recording plan only. No video recorded or uploaded.
Target: approximately 100 seconds, English narration and captions.
Use the actual local interface; never replace its output with invented screens.

## 0–15 seconds: the problem
Show the project form and the visible local-demo disclaimer.

“Before discussing a small building project with the municipality, owners need to know what information is missing. ByggeKlar turns a self-reported project checklist into concrete next steps.”

## 15–40 seconds: an incomplete case
Choose shed; keep Example municipality, leave measurements blank and all three document boxes unchecked. Click Review evidence. Show the actual findings, not an overlay pretending to be output.

“Here is an illustrative shed project with missing measurements and documents. The interface calls a real local MCP server. Its deterministic evidence checker identifies gaps rather than guessing that the project is ready.”

## 40–65 seconds: revise and review
Click Fill sample measurements. Show that old findings clear. Check the three document boxes, then run the review again.

“I can add sample measurements and record which documents I have. These are owner statements, not verified documents. A completed checklist still does not grant a building permit.”

## 65–85 seconds: evidence and reuse
Show the result disclaimer and download the actual review JSON. Briefly show the tool name review_building_evidence and recorded SDK test evidence without exposing personal files or credentials.

“The structured review can be exported. The server has been exercised with an independent MCP SDK client. This demonstration runs locally: it does not claim an Alexa connection, cloud deployment, or legal approval.”

## 85–100 seconds: close
Return to the app, keeping the limitations visible.

“The goal is a clearer preparation workflow: see missing evidence, update the case, and take better questions to the responsible authority.”

## Before publication
- Capture actual interaction, readable at phone size, with matching captions.
- Verify recorded output matches narration; do not call this AI reasoning or live Alexa.
- Keep the final video below the applicable competition limit after rechecking rules.
- Verify the public demo and repository links separately before submission.
- Preserve older submitted videos and do not change closed competition artifacts.
- No paid video tool, trial, music license, or cloud billing activation.
