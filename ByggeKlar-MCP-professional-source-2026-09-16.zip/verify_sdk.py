"""Reproducible interoperability check using the official MCP Python v1 client."""
import asyncio
import json
from datetime import datetime, timezone, timedelta
from importlib.metadata import version
from pathlib import Path
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def verify():
    params = StdioServerParameters(command=sys.executable,
        args=[str(Path(__file__).with_name('server.py').resolve())])
    case = dict(project_type='shed', municipality='Example municipality',
        area_m2=None, height_m=None, boundary_distance_m=None,
        has_site_plan=False, has_drawings=False, has_local_plan_reference=False)
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write, read_timeout_seconds=timedelta(seconds=10)) as session:
            init = await session.initialize()
            tools = await session.list_tools()
            assert [t.name for t in tools.tools] == ['review_building_evidence']
            missing = await session.call_tool('review_building_evidence', case)
            assert not missing.isError
            assert len(missing.structuredContent['documents_missing']) == 3
            completed_case = dict(case, area_m2=12, height_m=2, boundary_distance_m=3,
                has_site_plan=True, has_drawings=True, has_local_plan_reference=True)
            complete = await session.call_tool('review_building_evidence', completed_case)
            assert not complete.isError
            assert complete.structuredContent['documents_missing'] == []
            assert complete.structuredContent['permit_approved'] is False
            invalid = await session.call_tool('review_building_evidence', dict(case, area_m2=-1))
            assert invalid.isError
            await session.send_ping()
            return {
                'checked_at_utc': datetime.now(timezone.utc).isoformat(),
                'client': 'Official MCP Python SDK', 'sdk_version': version('mcp'),
                'protocol': init.protocolVersion, 'transport': 'local stdio',
                'scenarios': {'missing_documents': 'PASS', 'complete_checklist_not_permit': 'PASS',
                              'invalid_measurement_rejected': 'PASS', 'ping': 'PASS'},
                'missing_case_result': missing.structuredContent,
                'complete_case_result': complete.structuredContent,
                'limitations': ['Synthetic test data', 'No Alexa connection', 'No voice or LLM tested',
                               'Not a full protocol conformance suite', 'No municipal validation'],
            }


if __name__ == '__main__':
    print(json.dumps(asyncio.run(verify()), indent=2))
