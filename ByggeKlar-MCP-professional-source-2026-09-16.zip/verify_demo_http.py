"""Exercise the actual browser POST endpoint; start both servers first."""
import json
import urllib.request

case = dict(project_type='shed', municipality='Example', area_m2=None,
            height_m=None, boundary_distance_m=None, has_site_plan=False,
            has_drawings=False, has_local_plan_reference=False)


def check(arguments):
    request = urllib.request.Request('http://127.0.0.1:8765/review',
        data=json.dumps(arguments).encode(),
        headers={'Content-Type': 'application/json',
                 'Origin': 'http://127.0.0.1:8765'})
    with urllib.request.urlopen(request, timeout=15) as response:
        return json.load(response)


missing = check(case)
assert not missing['isError']
assert len(missing['structuredContent']['documents_missing']) == 3
case.update(area_m2=12, height_m=2, boundary_distance_m=3,
            has_site_plan=True, has_drawings=True, has_local_plan_reference=True)
complete = check(case)
assert not complete['isError']
assert complete['structuredContent']['documents_missing'] == []
assert complete['structuredContent']['permit_approved'] is False
case['area_m2'] = -1
assert check(case)['isError']
print('Browser POST endpoint: missing, complete-without-permit, invalid input PASS')
