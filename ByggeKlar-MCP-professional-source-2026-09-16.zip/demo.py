"""Loopback-only browser demo. Each review actually calls the MCP subprocess."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import subprocess
import sys
import asyncio

ROOT = Path(__file__).parent
HTTP_MODE = False


async def http_review(arguments):
    from mcp import ClientSession
    from mcp.client.streamable_http import streamablehttp_client
    async with streamablehttp_client('http://127.0.0.1:8766/mcp') as (read, write, _):
        async with ClientSession(read, write) as client:
            initialized = await client.initialize()
            if initialized.protocolVersion != '2025-11-25':
                raise ValueError('Unexpected protocol version')
            result = await client.call_tool('review_building_evidence', arguments)
            value = result.model_dump(mode='json', exclude_none=True)
            if not result.isError and not result.structuredContent:
                value['structuredContent'] = json.loads(result.content[0].text)
            return value


def call_review(arguments):
    if HTTP_MODE:
        return asyncio.run(http_review(arguments))
    messages = [
        dict(jsonrpc='2.0', id=1, method='initialize', params=dict(protocolVersion='2025-11-25', capabilities={}, clientInfo=dict(name='byggeklar-demo', version='0.1'))),
        dict(jsonrpc='2.0', method='notifications/initialized'),
        dict(jsonrpc='2.0', id=2, method='tools/call', params=dict(name='review_building_evidence', arguments=arguments)),
    ]
    process = subprocess.run([sys.executable, str(ROOT / 'server.py')],
        input='\n'.join(map(json.dumps, messages))+'\n', text=True,
        capture_output=True, timeout=10, check=True)
    replies = [json.loads(line) for line in process.stdout.splitlines()]
    return next(r['result'] for r in replies if r.get('id') == 2)


class Handler(BaseHTTPRequestHandler):
    def reply(self, status, data, content_type='application/json'):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == '/':
            self.reply(200, (ROOT / 'demo.html').read_bytes(), 'text/html; charset=utf-8')
        else:
            self.reply(404, b'{}')

    def do_POST(self):
        expected = 'http://127.0.0.1:8765'
        if self.path != '/review' or self.headers.get('Host') != '127.0.0.1:8765' or self.headers.get('Origin') != expected:
            return self.reply(403, b'{"error":"Local demo only"}')
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 16000:
                return self.reply(413, b'{}')
            result = call_review(json.loads(self.rfile.read(length)))
            self.reply(200, json.dumps(result).encode())
        except Exception:
            self.reply(400, b'{"error":"Review failed. Check your inputs and try again."}')

    def log_message(self, *args):
        pass


if __name__ == '__main__':
    HTTP_MODE = '--http' in sys.argv[1:]
    print('Transport: ' + ('Streamable HTTP' if HTTP_MODE else 'stdio'), flush=True)
    print('Local demo: http://127.0.0.1:8765', flush=True)
    ThreadingHTTPServer(('127.0.0.1', 8765), Handler).serve_forever()
